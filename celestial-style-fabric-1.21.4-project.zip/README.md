# Celestial Style Client — Fabric 1.21.4

A small client-side starter project inspired by the **general dark/purple click-GUI aesthetic** in the reference image. It is not the original Celestial client and does not include combat automation.

## Included
- Right Shift: open the menu
- G: toggle sprint
- Hold C: zoom (sets FOV to 30 while held, then restores the previous value)
- HUD with XYZ coordinates and sprint status
- Dark click GUI with HUD and ToggleSprint toggles

## Requirements
- Minecraft Java Edition 1.21.4
- Java Development Kit (JDK) 21
- Gradle (or open this folder in IntelliJ IDEA and let Gradle import it)
- Fabric Loader and Fabric API for Minecraft 1.21.4

## Build a JAR
1. Install JDK 21.
2. Extract this project folder.
3. Open a terminal in the folder containing `build.gradle`.
4. Run `gradle build` (or use `./gradlew build` if you add a Gradle wrapper).
5. The mod JAR will be created in `build/libs/`, named similar to `celestial-style-client-1.0.0.jar`.
6. Copy that JAR into `.minecraft/mods/` alongside Fabric API for 1.21.4.
7. Launch the Fabric 1.21.4 profile.

## Keybind changes
In Minecraft, open **Options → Controls → Key Binds → Celestial Style Client** and change the keys.

## Notes
- This is a starter source project, not a precompiled/verified JAR. The build downloads Fabric/Minecraft dependencies and therefore requires internet access.
- If Gradle reports a mapping/API mismatch, check the Fabric 1.21.4 documentation and update the relevant dependency versions.
- Use only in worlds/servers where your mods are permitted.
