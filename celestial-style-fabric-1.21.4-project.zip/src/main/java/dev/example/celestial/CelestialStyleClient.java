package dev.example.celestial;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class CelestialStyleClient implements ClientModInitializer {
    public static boolean hudEnabled = true;
    public static boolean toggleSprintEnabled = false;
    public static boolean zoomEnabled = false;

    private KeyBinding menuKey;
    private KeyBinding sprintToggleKey;
    private KeyBinding zoomKey;
    private double savedFov = 70.0;
    private boolean savedFovValid = false;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.celestial_style_client.open_menu",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.celestial_style_client"
        ));
        sprintToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.celestial_style_client.toggle_sprint",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G,
                "category.celestial_style_client"
        ));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.celestial_style_client.zoom",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C,
                "category.celestial_style_client"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new CelestialMenuScreen());
            }
            while (sprintToggleKey.wasPressed()) {
                toggleSprintEnabled = !toggleSprintEnabled;
            }

            boolean zoomDown = zoomKey.isPressed();
            if (client.options != null) {
                if (zoomDown && !zoomEnabled) {
                    savedFov = client.options.getFov().getValue();
                    savedFovValid = true;
                    zoomEnabled = true;
                    client.options.getFov().setValue(30.0);
                } else if (!zoomDown && zoomEnabled) {
                    zoomEnabled = false;
                    if (savedFovValid) {
                        client.options.getFov().setValue(savedFov);
                    }
                }
            }

            if (client.player != null && toggleSprintEnabled) {
                client.player.setSprinting(true);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!hudEnabled || client.player == null || client.world == null) return;
            renderHud(drawContext, client);
        });
    }

    private static void renderHud(DrawContext ctx, MinecraftClient client) {
        int x = 8, y = 8;
        ctx.fill(x - 4, y - 4, x + 184, y + 48, 0xB5101118);
        ctx.fill(x - 4, y - 4, x + 184, y - 2, 0xFF8B5CF6);
        ctx.drawTextWithShadow(client.textRenderer, Text.literal("CELESTIAL  /  1.21.4"), x, y, 0xFFFFFFFF);
        String coords = String.format("XYZ  %.1f  %.1f  %.1f",
                client.player.getX(), client.player.getY(), client.player.getZ());
        ctx.drawTextWithShadow(client.textRenderer, Text.literal(coords), x, y + 13, 0xFFBFC7D5);
        ctx.drawTextWithShadow(client.textRenderer,
                Text.literal("Sprint: " + (toggleSprintEnabled ? "ON" : "OFF")),
                x, y + 26, toggleSprintEnabled ? 0xFF67F0B0 : 0xFF9AA4B2);
    }

    public static class CelestialMenuScreen extends Screen {
        private int panelX, panelY, panelW = 300, panelH = 210;
        private CelestialMenuScreen() {
            super(Text.literal("Celestial"));
        }

        @Override
        protected void init() {
            panelX = (width - panelW) / 2;
            panelY = (height - panelH) / 2;
            int bx = panelX + 128;
            int bw = 160;
            int bh = 22;
            int gap = 8;
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("HUD  " + (hudEnabled ? "ON" : "OFF")),
                    b -> { hudEnabled = !hudEnabled; b.setMessage(Text.literal("HUD  " + (hudEnabled ? "ON" : "OFF"))); }
            ).dimensions(bx, panelY + 48, bw, bh).build());
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("ToggleSprint  " + (toggleSprintEnabled ? "ON" : "OFF")),
                    b -> { toggleSprintEnabled = !toggleSprintEnabled; b.setMessage(Text.literal("ToggleSprint  " + (toggleSprintEnabled ? "ON" : "OFF"))); }
            ).dimensions(bx, panelY + 48 + bh + gap, bw, bh).build());
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("Zoom: hold C"),
                    b -> {}
            ).dimensions(bx, panelY + 48 + (bh + gap) * 2, bw, bh).build());
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("Close"),
                    b -> close()
            ).dimensions(bx, panelY + 48 + (bh + gap) * 3, bw, bh).build());
        }

        @Override
        public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
            renderBackground(ctx, mouseX, mouseY, delta);
            ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF00B0D13);
            ctx.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFF8B5CF6);
            ctx.fill(panelX + 12, panelY + 38, panelX + 112, panelY + panelH - 12, 0xFF171A24);
            ctx.drawTextWithShadow(textRenderer, Text.literal("Celestial"), panelX + 14, panelY + 13, 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, Text.literal("Combat"), panelX + 22, panelY + 51, 0xFF9DA7B8);
            ctx.drawTextWithShadow(textRenderer, Text.literal("Movement"), panelX + 22, panelY + 73, 0xFFB58CFF);
            ctx.drawTextWithShadow(textRenderer, Text.literal("Render"), panelX + 22, panelY + 95, 0xFF9DA7B8);
            ctx.drawTextWithShadow(textRenderer, Text.literal("Player"), panelX + 22, panelY + 117, 0xFF9DA7B8);
            ctx.drawTextWithShadow(textRenderer, Text.literal("Utility"), panelX + 22, panelY + 139, 0xFF9DA7B8);
            ctx.drawTextWithShadow(textRenderer, Text.literal("RIGHT SHIFT  •  MENU"), panelX + 14, panelY + panelH - 18, 0xFF6F7889);
            super.render(ctx, mouseX, mouseY, delta);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}
